#!/bin/bash

ngxpg=tengine-2.1.2.tar.gz

check_ok() {
if [ $? != 0 ]
then
	echo "ERROR!Check the log"
	exit 1
fi
}

myum() {
if ! rpm -qa|grep -q "^$1"
then
     yum install -y $1
check_ok
else
     echo $1 already installed.
fi 
}

for p in install gcc openssl openssl-devel gd-devel libcurl-devel make
do
   myum $p
done

rpm -ivh ./perl-DBI-1.609-4.el6.x86_64.rpm
check_ok

unzip -q pcre-8.33.zip && cd pcre-8.33 && ./configure --enable-utf8 && make && make install

cd ../ && mkdir tengine && tar zxvf $ngxpg -C tengine --strip-components 1 && cd tengine 

rm -rf /etc/nginx

./configure --user=nginx --group=nginx --prefix=/etc/nginx --sbin-path=/usr/sbin/nginx --conf-path=/etc/nginx/nginx.conf --with-http_flv_module  --with-http_sub_module --with-http_ssl_module --with-http_ssl_module --with-http_concat_module  --with-http_stub_status_module --with-http_upstream_check_module  --with-http_realip_module --with-http_concat_module --without-http_upstream_consistent_hash_module  --with-http_gzip_static_module --with-http_mp4_module --with-http_stub_status_module --with-http_ssl_module --with-http_realip_module
check_ok

make && make install
check_ok

cd ../ && cp nginx.service /usr/lib/systemd/system/
cp nginx.conf /etc/nginx
mkdir /etc/nginx/conf.d

useradd nginx -s /sbin/nologin
systemctl start nginx


