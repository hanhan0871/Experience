#!/bin/bash

read -p "Please enter your ip: " ip
read -p "Please enter the redis version: " redis

check_ok() {
if [ $? != 0 ]
then
	echo "ERROR!Check the log"
	read -p "Skip this error? Y/N: " a
	if [ "$a" == "Y" ]
	then
		continue
	elif [ "$a" == "N" ]
	then
		exit 1  
	fi
fi
}

dir=`pwd`

if [ -f $redis.tar.gz ]
then 
	continue
else
	echo "Please enter redis version like: redis-3.2.12"
fi

tar zxf $redis.tar.gz && tar zxf tcl8.6.1-src.tar.gz 

cd tcl8.6.1/unix/ && ./configure && make && make install 
check-ok

cd ../$redis && make && cd src && make test
check-ok

if [ -d /data/redis ]
then 
	read -p "Delete /data/redis? Y/N: " r
	if [ "$r" == "Y" ]
	then
		rm -rf /data/redis
		continue
	elif [ "$r" == "N" ]
	then
		exit 1
fi

mkdir -p /data/redis/6379/{logs,var} && mkdir -p /data/redis/bin

cd src && cp redis-server redis-cli redis-check-aof redis-benchmark redis-sentinel /data/redis/bin

cd $dir/$redis/ && cp redis.conf /data/redis/6379/ && echo "bind $ip" >>/data/redis/6379/redis.conf

echo "### 系统参数变更，即将生效 ###"
sleep 1
if ! grep "vm.overcommit_memory = 1" /etc/sysctl.conf 
then
	echo "vm.overcommit_memory = 1" >> /etc/sysctl.conf
	echo 511 > /proc/sys/net/core/somaxconn 
	sysctl -p && echo "### 系统参数已生效###"
fi

echo "###Redis 启动中...... 运行ps -aux|grep redis查看进程###"
/data/redis/bin/redis-server /data/redis/6379/redis.conf &
fi

echo '/data/redis/bin/redis-server /data/redis/6379/redis.conf &' >> /etc/rc.local
