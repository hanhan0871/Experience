#!/bin/bash

check_ok() {
if [ $? != 0 ]
then
	echo "ERROR!Check the log"
	exit 1
fi
}

dir=`pwd`

yum install libevent libevent-devel patch -y

mkdir libevent && tar zxf libevent-*-stable.tar.gz -C libevent --strip-components 1

mkdir memcached && tar zxf memcached-*.tgz -C memcached --strip-components 1

cd libevent-* && ./configure --prefix=/usr/local/libevent --with-libevent=/usr/local/libevent
check_ok
make && make install
check_ok

cd ../memcached && patch -p1 -i ../repcached-2.3.1-1.4.13.patch
./configure --prefix=/usr/local/memcached --with-libevent=/usr/local/libevent --enable-replication
check_ok
make && make install
check_ok

echo "memcached -u root -d -l 127.0.0.1 -p 11211 -c 10240 -m 4096 to start memcached"

